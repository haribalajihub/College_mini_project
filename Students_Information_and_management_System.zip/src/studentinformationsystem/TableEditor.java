/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentinformationsystem;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.util.EventObject;
import javax.swing.AbstractCellEditor;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author HARI BALAJI
 */
public class TableEditor extends AbstractCellEditor implements TableCellEditor
{
  JTextField textField;    
  static int passcount=0;
  static int failcount=0;
  
   /*public TableEditor() 
    {
        textField=new JTextField();
        textField.setFont(new Font("Tahoma",Font.BOLD,18));       
        textField.setBorder(new LineBorder(Color.WHITE));
    }

    TableEditor(JTable myTable)
    {
        this.myTable=myTable;
        textField=new JTextField();
    }*/

    public JTextField getTextField() {
        return textField;
    }

    public int getPasscount() {
        return passcount;
    }

    public int getFailcount() {
        return failcount;
    }

    
    TableEditor()
    {
        super();
        textField=new JTextField();
        
       textField.setFont(new Font("Tahoma",Font.BOLD,18));       
       textField.setBorder(new LineBorder(Color.WHITE));
       //textField.setBackground(Color.RED);
    }

    
    
    @Override
    public Component getTableCellEditorComponent(JTable jtable, Object value, boolean bln, int rw, int col) 
    {                
        try
        {           
           textField.setText(value.toString());                  
        }
        catch(NullPointerException npe)
        {
            //System.out.println(npe.getMessage());
        }        
          return textField;
    }
    
   @Override   
    public Object getCellEditorValue() {
        String s=textField.getText();
        String empty="";
        int i = 0;
        if(!s.equals(""))
        {
            try
            {                
                i=Integer.parseInt(s);
                if(i<50)
                    textField.setForeground(Color.RED); 
                                        
            }
            catch(NumberFormatException nfe)
            {
                JOptionPane.showMessageDialog(null, "Please Give the Number");
                textField.requestFocus(true);
                textField.setText("");
            }
        }  
           return Integer.valueOf(i);        
    }

    @Override
    public boolean isCellEditable(EventObject eo) {       
                
        return true;
    }

    @Override
    public boolean shouldSelectCell(EventObject eo) {
        return true;
    }

    @Override
    public boolean stopCellEditing() 
    {
      
      try
      {
        Integer n=(Integer) getCellEditorValue();        
        int i=n.intValue();
        if(i<0||i>101)
        {
            JOptionPane.showMessageDialog(null, "Please Give the Number Between 0 and 100");
            //fireEditingCanceled();
            return false;
        }  
        if(i<50)
        {
            failcount=failcount+1;
            textField.setForeground(Color.RED);                                    
        }        
        else
            passcount=passcount+1;
      }
      catch(Exception e)
      {
          System.out.println(e.getMessage());
      }
        return super.stopCellEditing();
    }   

    
      
}


