/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentinformationsystem;

/**
 *
 * @author HARI BALAJI
 */
public class Semester
{
    String subjectcode,subjectname;

    public void setSubjectcode(String subjectcode) {
        this.subjectcode = subjectcode;
    }

    public void setSubjectname(String subjectname) {
        this.subjectname = subjectname;
    }

    public String getSubjectcode() {
        return subjectcode;
    }

    public String getSubjectname() {
        return subjectname;
    }
            
}
