/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentinformationsystem;

/**
 *
 * @author HARI BALAJI
 */
public class Internal 
{
    int rollno;
    String currentSem,SubjectName,CIA;

    public void setCurrentSem(String currentSem) {
        this.currentSem = currentSem;
    }

    public String getCurrentSem() {
        return currentSem;
    }
    int mark;

    public int getRollno() {
        return rollno;
    }

    public String getSubjectName() {
        return SubjectName;
    }

    public String getCIA() {
        return CIA;
    }

    public int getMark() {
        return mark;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public void setSubjectName(String SubjectName) {
        this.SubjectName = SubjectName;
    }

    public void setCIA(String CIA) {
        this.CIA = CIA;
    }

    public void setMark(int mark) {
        this.mark = mark;
    }
    
}
