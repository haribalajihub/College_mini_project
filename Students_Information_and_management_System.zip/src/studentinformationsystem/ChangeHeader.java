/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentinformationsystem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author HARI BALAJI
 */
public class ChangeHeader implements TableModelListener
{
    Connection conn=null;
    PreparedStatement pst=null;
    ResultSet rs=null;
    DefaultTableModel model;
    ArrayList<Semester> al=new ArrayList<Semester>();
    ChangeHeader(String semester)
    {
        conn = dbconnect.java_db();
        try {
            pst=conn.prepareStatement("SELECT SUBJECTCODE,SUBJECTNAME FROM SEMESTER WHERE SEM=?");
            pst.setString(1,semester);
            rs=pst.executeQuery();
            while(rs.next())
            {
               Semester obj=new Semester();
               obj.setSubjectcode(rs.getString("SUBJECTCODE"));
               obj.setSubjectname(rs.getString("SUBJECTNAME"));
               al.add(obj);
            }
          
        } catch (SQLException ex) {
            Logger.getLogger(ChangeHeader.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public ArrayList<Semester> getList()
    {
        return al;
    }
    @Override
    public void tableChanged(TableModelEvent tme) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
