/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentinformationsystem;

/**
 *
 * @author HARI BALAJI
 */
public class Internal2 
{
    int rollno;
    String currentSem,SubjectName;
    int CIA1,CIA2,CIA3,CIA4;

    public void setCurrentSem(String currentSem) {
        this.currentSem = currentSem;
    }

    public String getCurrentSem() {
        return currentSem;
    }    

    public int getRollno() {
        return rollno;
    }

    public String getSubjectName() {
        return SubjectName;
    }

   

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public void setSubjectName(String SubjectName) {
        this.SubjectName = SubjectName;
    }

    public int getCIA1() {
        return CIA1;
    }

    public int getCIA2() {
        return CIA2;
    }

    public int getCIA3() {
        return CIA3;
    }

    public int getCIA4() {
        return CIA4;
    }

    public void setCIA1(int CIA1) {
        this.CIA1 = CIA1;
    }

    public void setCIA2(int CIA2) {
        this.CIA2 = CIA2;
    }

    public void setCIA3(int CIA3) {
        this.CIA3 = CIA3;
    }

    public void setCIA4(int CIA4) {
        this.CIA4 = CIA4;
    }

   
    
}
