/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentinformationsystem;

import java.awt.Color;
import java.awt.Component;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

/**
 *
 * @author HARI BALAJI
 */
public class MyTableRenderer extends  DefaultTableCellRenderer {
public static final DefaultTableCellRenderer DEFAULT_RENDERER = new DefaultTableCellRenderer();    
    public MyTableRenderer() 
    {
       
    }
    
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
         JLabel label = new JLabel();
                 
        try
        {                        
            label.setText(value.toString());
            
            int i=Integer.parseInt(label.getText());            
            System.out.println("i="+i);
            if(i<50)
            {                
                label.setForeground(Color.RED);
                
            }
            else
            {
                label.setForeground(Color.BLACK);
                
            }            
        }
        catch(Exception e)
        {
         //System.out.println(e.getMessage());
        }
        return label;        
    }

   
    
    
}
